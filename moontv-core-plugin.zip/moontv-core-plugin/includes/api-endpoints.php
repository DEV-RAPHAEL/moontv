<?php
// Expose post meta fields to the Next.js REST API
add_action( 'rest_api_init', 'moontv_register_rest_fields' );

function moontv_register_rest_fields() {
    // Expose all custom schedule data securely to `/wp-json/wp/v2/schedule`
    register_rest_field( 'schedule', 'schedule_details', array(
        'get_callback' => 'moontv_get_schedule_details',
        'schema' => null,
    ));

    // Expose advanced layout fields for Programmes
    register_rest_field( 'programme', 'advanced_details', array(
        'get_callback' => 'moontv_get_programme_advanced_details',
        'schema' => null,
    ));

    // Expose plain image URLs to Next.js array (saves complex parsing on frontend)
    register_rest_field( array('programme'), 'featured_image_url', array(
        'get_callback' => 'moontv_get_featured_image_url',
        'schema' => null,
    ));
}

function moontv_get_programme_advanced_details( $object, $field_name, $request ) {
    $post_id = $object['id'];
    return array(
        'time'            => get_post_meta( $post_id, '_programme_time', true ),
        'category_badge'  => get_post_meta( $post_id, '_programme_category_badge', true ),
        'purpose'         => get_post_meta( $post_id, '_programme_purpose', true ),
        'audience'        => get_post_meta( $post_id, '_programme_audience', true ),
        'format'          => get_post_meta( $post_id, '_programme_format', true ),
        'personality'     => get_post_meta( $post_id, '_programme_personality', true ),
        'context'         => get_post_meta( $post_id, '_programme_context', true ),
    );
}

function moontv_get_schedule_details( $object, $field_name, $request ) {
    $post_id = $object['id'];
    $programme_id = get_post_meta( $post_id, '_programme_id', true );
    
    return array(
        'start_time'   => get_post_meta( $post_id, '_start_time', true ),
        'end_time'     => get_post_meta( $post_id, '_end_time', true ),
        'day_of_week'  => get_post_meta( $post_id, '_day_of_week', true ),
        'programme_id' => $programme_id,
        // Send down the programme title directly to save Next.js an extra API call
        'programme_title' => $programme_id ? get_the_title( $programme_id ) : null,
        'programme_slug'  => $programme_id ? get_post_field( 'post_name', $programme_id ) : null,
        'programme_thumbnail' => $programme_id ? get_the_post_thumbnail_url($programme_id, 'full') : null,
    );
}

function moontv_get_featured_image_url( $object, $field_name, $request ) {
    if( $object['featured_media'] ){
        return wp_get_attachment_image_url( $object['featured_media'], 'full' );
    }
    return null;
}
