<?php
function moontv_register_programme_cpt() {
    $labels = array(
        'name'                  => 'Programmes',
        'singular_name'         => 'Programme',
        'menu_name'             => 'Programmes',
        'add_new'               => 'Add New Programme',
        'add_new_item'          => 'Add New Programme',
        'edit_item'             => 'Edit Programme',
        'new_item'              => 'New Programme',
        'view_item'             => 'View Programme',
        'search_items'          => 'Search Programmes',
    );
    $args = array(
        'label'                 => 'Programme',
        'labels'                => $labels,
        'supports'              => array( 'title', 'editor', 'thumbnail', 'excerpt' ),
        'taxonomies'            => array( 'programme_category' ),
        'public'                => true,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'menu_icon'             => 'dashicons-video-alt3',
        'show_in_rest'          => true, // Exposes to REST API for Next.js
        'has_archive'           => true,
        'rewrite'               => array( 'slug' => 'programmes' ),
    );
    register_post_type( 'programme', $args );

    $tax_labels = array(
        'name'              => 'Programme Categories',
        'singular_name'     => 'Programme Category',
        'search_items'      => 'Search Categories',
        'all_items'         => 'All Categories',
        'edit_item'         => 'Edit Category',
        'update_item'       => 'Update Category',
        'add_new_item'      => 'Add New Category',
        'new_item_name'     => 'New Category Name',
        'menu_name'         => 'Categories',
    );
    $tax_args = array(
        'hierarchical'      => true,
        'labels'            => $tax_labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'show_in_rest'      => true, // Essential to access via REST
        'query_var'         => true,
        'rewrite'           => array( 'slug' => 'programme-category' ),
    );
    register_taxonomy( 'programme_category', array( 'programme' ), $tax_args );
}
add_action( 'init', 'moontv_register_programme_cpt' );

// Add Custom Fields for the Advanced Frontend Layout
function moontv_programme_meta_boxes() {
    add_meta_box( 'programme_details', 'Programme Advanced Details', 'moontv_programme_meta_callback', 'programme', 'normal', 'high' );
}
add_action( 'add_meta_boxes', 'moontv_programme_meta_boxes' );

function moontv_programme_meta_callback( $post ) {
    wp_nonce_field( 'moontv_programme_save_meta', 'moontv_programme_meta_nonce' );

    $time = get_post_meta( $post->ID, '_programme_time', true );
    $category_badge = get_post_meta( $post->ID, '_programme_category_badge', true );
    $purpose = get_post_meta( $post->ID, '_programme_purpose', true );
    $audience = get_post_meta( $post->ID, '_programme_audience', true );
    $format = get_post_meta( $post->ID, '_programme_format', true );
    $personality = get_post_meta( $post->ID, '_programme_personality', true );
    $context = get_post_meta( $post->ID, '_programme_context', true );

    echo '<div style="display:flex; flex-direction:column; gap:15px;">';
    
    echo '<div><label for="programme_time"><strong>Broadcast Time string (e.g. "Mon - Fri • 18:00 WAT"):</strong></label><br/>';
    echo '<input type="text" id="programme_time" name="programme_time" value="' . esc_attr( $time ) . '" style="width:100%; max-width:600px; padding:6px;"/></div>';

    echo '<div><label for="programme_category_badge"><strong>Hero Badge Text (e.g. "FLAGSHIP TALK SHOW"):</strong></label><br/>';
    echo '<input type="text" id="programme_category_badge" name="programme_category_badge" value="' . esc_attr( $category_badge ) . '" style="width:100%; max-width:600px; padding:6px;"/></div>';

    echo '<div><label for="programme_purpose"><strong>Show Purpose (Use bullet points format "- Item 1 \n- Item 2"):</strong></label><br/>';
    echo '<textarea id="programme_purpose" name="programme_purpose" rows="4" style="width:100%; max-width:600px; padding:6px;">' . esc_textarea( $purpose ) . '</textarea></div>';

    echo '<div><label for="programme_audience"><strong>Core Audience (Use bullet points format "- Item 1 \n- Item 2"):</strong></label><br/>';
    echo '<textarea id="programme_audience" name="programme_audience" rows="3" style="width:100%; max-width:600px; padding:6px;">' . esc_textarea( $audience ) . '</textarea></div>';

    echo '<div><label for="programme_format"><strong>Format Overview:</strong></label><br/>';
    echo '<textarea id="programme_format" name="programme_format" rows="3" style="width:100%; max-width:600px; padding:6px;">' . esc_textarea( $format ) . '</textarea></div>';

    echo '<div><label for="programme_personality"><strong>Show Personality:</strong></label><br/>';
    echo '<textarea id="programme_personality" name="programme_personality" rows="3" style="width:100%; max-width:600px; padding:6px;">' . esc_textarea( $personality ) . '</textarea></div>';

    echo '<div><label for="programme_context"><strong>Broadcasting Context (Bottom highlighted text):</strong></label><br/>';
    echo '<textarea id="programme_context" name="programme_context" rows="3" style="width:100%; max-width:600px; padding:6px;">' . esc_textarea( $context ) . '</textarea></div>';

    echo '</div>';
    echo '<p style="color: #666; font-style: italic;">Note: The main "Synopsis" should be typed in the standard WordPress Text Editor at the top.</p>';
}

function moontv_programme_save_meta( $post_id ) {
    if ( ! isset( $_POST['moontv_programme_meta_nonce'] ) || ! wp_verify_nonce( $_POST['moontv_programme_meta_nonce'], 'moontv_programme_save_meta' ) ) return;
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    if ( ! current_user_can( 'edit_post', $post_id ) ) return;

    $fields = array(
        'programme_time' => '_programme_time',
        'programme_category_badge' => '_programme_category_badge',
        'programme_purpose' => '_programme_purpose',
        'programme_audience' => '_programme_audience',
        'programme_format' => '_programme_format',
        'programme_personality' => '_programme_personality',
        'programme_context' => '_programme_context',
    );

    foreach ( $fields as $post_key => $meta_key ) {
        if ( isset( $_POST[$post_key] ) ) {
            // Using sanitize_textarea_field to allow newlines for bullets
            update_post_meta( $post_id, $meta_key, sanitize_textarea_field( $_POST[$post_key] ) );
        }
    }
}
add_action( 'save_post', 'moontv_programme_save_meta' );
