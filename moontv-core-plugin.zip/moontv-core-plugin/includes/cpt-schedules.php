<?php
function moontv_register_schedule_cpt() {
    $labels = array(
        'name'                  => 'Schedules (EPG)',
        'singular_name'         => 'Schedule',
        'menu_name'             => 'EPG Schedule',
        'add_new'               => 'Add New Slot',
        'add_new_item'          => 'Add New Schedule Slot',
        'edit_item'             => 'Edit Schedule',
    );
    $args = array(
        'labels'                => $labels,
        'supports'              => array( 'title' ),
        'public'                => true,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'menu_icon'             => 'dashicons-calendar-alt',
        'show_in_rest'          => true, // Essential for Next.js
        'has_archive'           => false,
    );
    register_post_type( 'schedule', $args );
}
add_action( 'init', 'moontv_register_schedule_cpt' );

// Add Meta Boxes for Custom Fields
function moontv_schedule_meta_boxes() {
    add_meta_box( 'schedule_details', 'Schedule Details', 'moontv_schedule_meta_callback', 'schedule', 'normal', 'high' );
}
add_action( 'add_meta_boxes', 'moontv_schedule_meta_boxes' );

function moontv_schedule_meta_callback( $post ) {
    wp_nonce_field( 'moontv_schedule_save_meta', 'moontv_schedule_meta_nonce' );

    $start_time = get_post_meta( $post->ID, '_start_time', true );
    $end_time = get_post_meta( $post->ID, '_end_time', true );
    $day_of_week = get_post_meta( $post->ID, '_day_of_week', true );
    $programme_id = get_post_meta( $post->ID, '_programme_id', true );

    $programmes = get_posts(array(
        'post_type' => 'programme',
        'numberposts' => -1,
        'orderby' => 'title',
        'order' => 'ASC'
    ));

    echo '<p><label for="programme_id"><strong>Select Programme:</strong></label><br/>';
    echo '<select name="programme_id" id="programme_id" style="width:100%; max-width:400px; padding:6px;">';
    echo '<option value="">-- Select Programme --</option>';
    foreach ($programmes as $prog) {
        $selected = ($programme_id == $prog->ID) ? 'selected' : '';
        echo '<option value="' . esc_attr($prog->ID) . '" ' . $selected . '>' . esc_html($prog->post_title) . '</option>';
    }
    echo '</select></p>';

    echo '<p><label for="day_of_week"><strong>Day of Week:</strong></label><br/>';
    echo '<select name="day_of_week" id="day_of_week" style="padding:6px;">';
    $days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    foreach ($days as $day) {
        $selected = ($day_of_week === $day) ? 'selected' : '';
        echo '<option value="' . esc_attr($day) . '" ' . $selected . '>' . esc_html($day) . '</option>';
    }
    echo '</select></p>';

    echo '<p><label for="start_time"><strong>Start Time:</strong></label><br/>';
    echo '<input type="time" id="start_time" name="start_time" value="' . esc_attr( $start_time ) . '" style="padding:6px;"/></p>';

    echo '<p><label for="end_time"><strong>End Time:</strong></label><br/>';
    echo '<input type="time" id="end_time" name="end_time" value="' . esc_attr( $end_time ) . '" style="padding:6px;"/></p>';
}

function moontv_schedule_save_meta( $post_id ) {
    if ( ! isset( $_POST['moontv_schedule_meta_nonce'] ) || ! wp_verify_nonce( $_POST['moontv_schedule_meta_nonce'], 'moontv_schedule_save_meta' ) ) return;
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    if ( ! current_user_can( 'edit_post', $post_id ) ) return;

    if ( isset( $_POST['start_time'] ) ) update_post_meta( $post_id, '_start_time', sanitize_text_field( $_POST['start_time'] ) );
    if ( isset( $_POST['end_time'] ) ) update_post_meta( $post_id, '_end_time', sanitize_text_field( $_POST['end_time'] ) );
    if ( isset( $_POST['day_of_week'] ) ) update_post_meta( $post_id, '_day_of_week', sanitize_text_field( $_POST['day_of_week'] ) );
    if ( isset( $_POST['programme_id'] ) ) update_post_meta( $post_id, '_programme_id', sanitize_text_field( $_POST['programme_id'] ) );
}
add_action( 'save_post', 'moontv_schedule_save_meta' );
