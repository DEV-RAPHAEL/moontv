<?php
/**
 * Plugin Name: Moon TV Core Features
 * Description: Registers Custom Post Types (Programmes, Schedules), Taxonomies, and REST API extensions for the Moon TV Headless Platform.
 * Version: 1.0.0
 * Author: PRMP Digital
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

define( 'MOONTV_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

// Include Custom Post Types
require_once MOONTV_PLUGIN_DIR . 'includes/cpt-programmes.php';
require_once MOONTV_PLUGIN_DIR . 'includes/cpt-schedules.php';

// Include REST API Customizations
require_once MOONTV_PLUGIN_DIR . 'includes/api-endpoints.php';

// Flush rewrite rules on activation
register_activation_hook( __FILE__, 'moontv_rewrite_flush' );
function moontv_rewrite_flush() {
    moontv_register_programme_cpt();
    moontv_register_schedule_cpt();
    flush_rewrite_rules();
}
